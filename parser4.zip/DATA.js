DOPE.prototype.STATE = {
	"devices": [
		{
			"type": "RAM",
			"size": 1*1024*1024,
			"data": "",
			"gpt": null,
			"sector_size": 512
		},
		{
			"type": "HDD",
			"size": 10*1024*1024,
			"data": "",
			"gpt": null,
			"sector_size": 512
		}
	]
};