
DOPE.prototype.Memory = function () {

	var _self = this,
		sector_buffer = new Array (256+1).join ("0"),
		read_buffer = "",
		write_buffer = "";
		
		VAR_LENGTH = {
			'byte': 1,
			'char': 2,
			'int': 4,
			'long': 8
		};
		
		GPT_MAPPING_OFFSET = {
		'signature': 0,
		'revision': 8,
		'header_size': 12,
		'header_crc32': 16,
		'reserved1': 20,
		'current_lba': 24,
		'backup_lba': 32,
		'first_lba': 40,
		'last_lba': 48,
		'guid': 56,
		'partition_array_start_lba': 72,
		'partition_array_length': 80,
		'partition_array_entries_size': 84,
		'partition_array_crc32': 88,
		'reserved2': 92
		};
		
		GPT_MAPPING_SIZE = {
		'signature': 8,
		'revision': 4,
		'header_size': 4,
		'header_crc32': 4,
		'reserved1': 4,
		'current_lba': 8,
		'backup_lba': 8,
		'first_lba': 8,
		'last_lba': 8,
		'guid': 16,
		'partition_array_start_lba': 8,
		'partition_array_length': 4,
		'partition_array_entries_size': 4,
		'partition_array_crc32': 4,
		'reserved2': -1
		};
	
	return {
		'init': init,
		'debug': debug,
		'isDevice': isDevice,
		'listDevices': listDevices,
		'parseGPT': parseGPT,
		'storeGPT': storeGPT,
		'isAddress': isAddress,
		'getAddressFromSector': getAddressFromSector,
		'isSector': isSector,
		'getSectorByAddress': getSectorByAddress,
		'readSectorData': readSectorData,
		'writeSectorData': writeSectorData,
		'getSectorOffset': getSectorOffset,
		'getAddressByOffset': getAddressByOffset,
		'readData': readData,
		'writeData': writeData,
		'readBytes': readBytes,
		'writeBytes': writeBytes,
		'readString': readString,
		'writeString': writeString
	};
	
	function init (module) {
		require ("STATE");
	}
	
	function debug () {
		console.log ("//Sector buffer:\n"+sector_buffer+"\n//Read buffer:\n"+read_buffer+"\n//Write buffer:\n"+write_buffer);
	}
	
	function isDevice (device) {
		if (device >= 0 && device < STATE.devices.length) {
			return true;
		}
		return false;
	}
	
	function VASAddress (address) {
		var vas;
		for (var x = 0, vas = address; x < STATE.devices.length; x++) {
			if (vas > STATE.devices[x].size) {
				return vas;
			}
			vas -= STATE.devices[x].size;
		}
		return;
	}
	
	function VASDevice (address) {
		var vas;
		for (var x = 0, vas = address; x < STATE.devices.length; x++) {
			if (vas > STATE.devices[x].size) {
				return x;
			}
			vas -= STATE.devices[x].size;
		}
		return;
	}
	
	function listDevices (offset) {
		var x,
		list = [];
		if (!isSet (offset)) {
			offset = 0;
		} else if (isDevice (offset)) {
			for (x = offset; x < STATE.devices.length; x++) {
				list.push (x);
			}
		}
		return list;
	}
	
	function parseGPT (device) {
		var x,
			gpt = {};
		if (isDevice (device)) {
			for (x in GPT_MAPPING_OFFSET) {
				if (seek (device, GPT_MAPPING_OFFSET[x])) {
					gpt[x] = read (device, GPT_MAPPING_SIZE[x]);
				} else {
					break;
				}
			}
			STATE.devices[device].gpt = gpt;
			return true;
		}
		return false;
	}
	
	function storeGPT (device) {
		var x;
		if (isDevice (device)) {
			for (x in GPT_MAPPING_OFFSET) {
				if (seek (device, GPT_MAPPING_OFFSET[x])) {
					write (device, GPT_MAPPING_OFFSET[x], STATE.devices[device].gpt[x]);
				} else {
					break;
				}
			}
			return true;
		}
		return false;
	}
	
	function generateGPT (device) {
		
	}
	
	// Parse GPT header into object
	function _parseGPT () {
		var gpt = {}, tmp_buffer;
		// Loop throught sectors from LBA 0 in search for header
		for (var x = 0; x < storage[active_drive].length; x++) {
			if (storage[active_drive][x] instanceof String) {
				// Extract header information
				tmp_buffer = storage[active_drive][x];
				gpt.signature = tmp_buffer.substr (0, 8);
				gpt.verstion = tmp_buffer.substr (8, 4);
				gpt.header_size = tmp_buffer.substr (12, 4);
				gpt.header_crc = tmp_buffer.substr (16, 4);
				gpt.reserved = tmp_buffer.substr (20, 4);
				gpt.current_lba = tmp_buffer.substr (24, 8);
				gpt.backup_lba = tmp_buffer.substr (32, 8);
				gpt.first_lba = tmp_buffer.substr (40, 8);
				gpt.last_lba = tmp_buffer.substr (48, 8);
				gpt.disk_guid = tmp_buffer.substr (56, 16);
				gpt.partition_array_lba = tmp_buffer.substr (72, 8);
				gpt.partition_array_length = tmp_buffer.substr (80, 4);
				gpt.partition_entry_size = tmp_buffer.substr (84, 4);
				gpt.partition_array_crc = tmp_buffer.substr (88, 4);
				gpt.parition_array = [];
				// Check if EFI Partition
				if (gpt.signature == "EFI PART") {
					console.log ("GPT header found.");
					// Check integrity of header
					tmp_buffer = tmp_buffer.substr (0, 16)+"0000"+tmp_buffer.substr (20, gpt.header_size-20);
					if (gpt.header_crc == _self.device.crc32 (tmp_buffer)) {
						console.log ("GPT primary header intact.");
						// Check integrity of partition array
						tmp_buffer = "";
						for (var y = gpt.partition_array_lba; y < (gpt.partition_array_lba+gpt.partition_array_length*gpt.partition_entry_size/sector_size); y++) {
							tmp_buffer += storage[active_drive][y];
						}
						tmp_buffer = tmp_buffer.substr (0, gpt.partition_array_length*gpt.partition_entry_size);
						if (gpt.partition_array_crc == _self.device.crc32 (tmp_buffer)) {
							console.log ("GPT partition array intact.");
							for (var y = 0; y < gpt.partition_array_length; y++) {
								// Extract partition entries
								gpt.partition_array.push ({
									type_guid: tmp_buffer.substr (y*gpt.partition_entry_size, 16),
									unique_guid: tmp_buffer.substr (y*gpt.partition_entry_size+16, 16),
									first_lba: tmp_buffer.substr (y*gpt.partition_entry_size+32, 8),
									last_lba: tmp_buffer.substr (y*gpt.partition_entry_size+40, 8),
									attribute_flags: tmp_buffer.substr (y*gpt.partition_entry_size+48, 8),
									utf16_name: tmp_buffer.substr (y*gpt.partition_entry_size+56, 72)
								});
							}
							console.log ("Found "+pgt.partition_array.length+" partitions.");
							return gpt;
						}
					} else if (gpt.current_header < gpt.backup_header) {
						// If corrupted primary header, check secondary
						console.log ("GPT primary header corrupt.");
						x = gpt.backup_lba;
						continue;
					} else {
						// If both GPT headers are corrupt, stop searching (possibly try to repair with interpolation)
						console.log ("GPT secondary header corrupt.");
						return false;
					}
				}
			}
		}
	}
	
	function isAddress (device, address) {
		if (isDevice (device)) {
			if (address >= 0 && address < STATE.devices[device].size) {
				return true;
			}
		}
		return false;
	}
	
	function getAddressFromSector (device, sector) {
		if (isSector (device, sector)) {
			return STATE.devices[device].sector_size*sector;
		}
		return -1;
	}
	
	function isSector (device, sector) {
		if (isDevice (device) && sector >= 0 && sector < STATE.devices[device].size/STATE.devices[device].sector_size) {
			return true;
		}
		return false;
	}
	
	function getSectorByAddress (device, address) {
		if (isAddress (device, address)) {
			return ((address-(address%STATE.devices[device].sector_size))/STATE.devices[device].sector_size);
		}
		return -1;
	}
	
	function getReadBuffer () {
		return read_buffer;
	}
	
	function setWriteBuffer (data) {
		write_buffer = data;
		return true;
	}
	
	function readSectorData (device, sector) {
		if (isDevice (device)) {
			sector_buffer = STATE.devices[device].data.substr (getAddressFromSector (device, sector), STATE.devices[device].sector_size);
			return true;
		}
		return false;
	}
	
	function writeSectorData (device, sector) {
		if (isSector (device, sector)) {
			STATE.devices[device].data = STATE.devices[device].data.substr (0, getAddressFromSector (device, sector))+sector_buffer+STATE.devices[device].data.substr (getAddressFromSector (device, sector+1))
			//sector_buffer = "";
			return true;
		}
		return false;
	}
	
	function getSectorOffset (device, address, sector) {
		if (!isSet (sector) || !isSector (sector)) {
			sector = 0;
		}
		if (isAddress (device, address)) {
			return address-(sector*STATE.devices[device].sector_size);
		}
		return 0;
	}
	
	function getAddressByOffset (device, offset, sector) {
		var address;
		if (!isSet (sector) || !isSector (sector)) {
			sector = 0;
		}
		if (!isSet (offset) || !isSector (offset)) {
			offset = 0;
		}
		if (isAddress (device, address = offset+getAddressBySector (device, sector))) {
			return address;
		}
		return 0;
	}

	function readData (device, pointer, length) {
		var sector,
			start_offset,
			stop_offset,
			start_sector,
			stop_sector;
		if (!isAddress (device, pointer)) {
			return false;
		}
		if (length == -1) {
			length = STATE.devices[device].size-pointer;
		}
		if (isAddress (device, pointer+length)) {
			read_buffer = ""; 
			start_offset = pointer&STATE.devices[device].sector_size;
			stop_offset = (pointer+length)%STATE.devices[device].sector_size;
			start_sector = getSectorByAddress (device, pointer);
			stop_sector = getSectorByAddress (device, pointer+length);
			sector = start_sector;
			while (sector <= stop_sector) {
				readSectorData (device, sector);
				if (sector == start_sector) {
					read_buffer += sector_buffer.substr (start_offset);
				} else if (sector == stop_sector) {
					read_buffer += sector_buffer.substr (0, stop_offset);
				} else {
					read_buffer += sector_buffer;
				}
				sector++;
			}
			//sector_buffer = new Array (256+1).join ("0");
			return true;
		}
		return false;
	}
	
	function writeData (device, pointer) {
		var sector,
			start_offset,
			stop_offset,
			start_sector,
			stop_sector,
			length = write_buffer.length;
		if (!isAddress (device, pointer)) {
			return false;
		}
		if (length == 0) {
			return true;
		}
		if (isAddress (device, pointer+length)) {
			start_offset = pointer&STATE.devices[device].sector_size;
			stop_offset = (pointer+length)%STATE.devices[device].sector_size;
			start_sector = getSectorByAddress (device, pointer);
			stop_sector = getSectorByAddress (device, pointer+length);
			sector = start_sector;
			while (sector <= stop_sector) {
				if (sector == start_sector) {
					sector_buffer = sector_buffer.substr (0, start_offset)+write_buffer.substr (0, STATE.devices[device].sector_size-start_offset);
				} else if (sector == stop_sector) {
					sector_buffer = write_buffer.substr ((sector-start_sector)*STATE.devices[device].sector_size, stop_offset)+sector_buffer.substr (stop_offset);
				} else {
					sector_buffer = write_buffer.substr ((sector-start_sector)*STATE.devices[device].sector_size, STATE.devices[device].sector_size);
				}
				console.log ("write: "+sector_buffer);
				writeSectorData (device, sector);
				sector++;
			}
			write_buffer = "";
			return true;
		}
		return false;
	}
	
	function readBytes (pointer, length) {
		var bytes = "";
		for (var x = pointer; x < length; x++) {
			bytes += read_buffer[x];
		}
		return parseInt (bytes, 16);
	}
	
	function writeBytes (pointer, bytes) {
		bytes = bytes.toString (16);
		if (write_buffer.length < pointer+bytes.length) {
			write_buffer += new Array (pointer+bytes.length-write_buffer.length+1).join ("0");
		}
		write_buffer = write_buffer.substr (0, pointer)+bytes+write_buffer.substr (pointer+bytes.length);
		//for (var x = 0; x < bytes.length; x++) {
			//write_buffer[x+pointer] = bytes[x];
		//}
		return write_buffer.length;
	}
	
	function readString (pointer, length) {
		var string = "";
		for (var x = 0; x < length; x++) {
			string += String.fromCharCode (parseInt (readBytes ((pointer+x)*VAR_LENGTH.char, VAR_LENGTH.char), 10));
		}
		return string;
	}
	
	function writeString (pointer, string) {
		for (var x = 0; x < string.length; x++) {
			writeBytes (pointer+(x*VAR_LENGTH.char), string.charCodeAt (x));
		}
	}
}