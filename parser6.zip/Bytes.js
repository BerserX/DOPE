TYPE = {
	'byte': 1,
	'char': 2,
	'int': 4,
	'long': 8
};

function Number (bytes) {
	var number;
	if (isSet (bytes)) {
		number = 0;
		for (var x = 0; x < bytes.length; x++) {
			number = (number << 8) | bytes[x];
		}
	}
	return number;
}

function Byte (number) {
	var bytes;
	if (isSet (number)) {
		bytes = new Int8Array (new ArrayBuffer (TYPE.byte));
		for (var x = 0; x < bytes.length; x++) {
			bytes[x] = 0xf0 & number;
			number = number << 8;
		}
	}
	return bytes;
}

function Char (number) {
	var bytes;
	if (isSet (number)) {
		bytes = new Int8Array (new ArrayBuffer (TYPE.char));
		for (var x = 0; x < bytes.length; x++) {
			bytes[x] = 0xff & number;
			number = number << 8;
		}
	}
	return bytes;
}

function Int (number) {
	var bytes;
	if (isSet (number)) {
		bytes = new Int8Array (new ArrayBuffer (TYPE.int));
		for (var x = 0; x < bytes.length; x++) {
			bytes[x] = 0xff & number;
			number = number << 8;
		}
	}
	return bytes;
}

function Long (number) {
	var bytes;
	if (isSet (number)) {
		bytes = new Int8Array (new ArrayBuffer (TYPE.long));
		for (var x = 0; x < bytes.length; x++) {
			bytes[x] = 0xff & number;
			number = number << 8;
		}
	}
	return bytes;
}

function String (bytes)